package com.birlasoft.automation.pages;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.birlasoft.automation.driver.TestConfig;
import com.birlasoft.automation.tests.TestsCond;
import com.birlasoft.framework.LogMe;
import com.birlasoft.utils.TestData;
import com.birlasoft.utils.UIUtils; 

public class CodeMaintanenceDiag extends AbstractPage {


	//static Logger LOGGER = Logger.getLogger(HomePage.class);
	//static Logger LOGGER = Logger.getLogger(CodeMaintanence.class); // using logger of apache 

	static LogMe LOGGER= new LogMe(CodeMaintanenceDiag.class); // using logger of frame work 
	WebDriverWait wWait;

	public CodeMaintanenceDiag(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
		wWait = new WebDriverWait(driver, Integer.parseInt(TestConfig.getConfig().getPropertyValue("AVGWAITTIME")));
	}

	//LOGGER = new LogMe(CodeMaintanence.class);

	@Override
	public boolean isPageOpen() throws IOException {

		boolean isExist = false;

		isExist = UIUtils.isObjectExist(driver,
				TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "submenuDiagText"));
		WebElement element = driver.findElement(TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "submenuDiagText")) ;

		// UIUtils.getText(element);
		System.out.println("the text is "+UIUtils.getText(element));
		//LOGGER.info("The page is "+UIUtils.getText(element));
		LOGGER.logTestStep("PASS", "We are on page "+UIUtils.getText(element)  );

		return isExist;



	}

	@Override
	public boolean isPageOpen(String subMenuType ) throws IOException {


		return true;
	}

	/*
	 *
	public void selectSubMenu(String subMenuType) throws Exception {


		System.out.println("subMenuType call "+subMenuType);
		System.out.println("subMenuType call caps  "+subMenuType.toUpperCase());

		switch (subMenuType.toUpperCase()) {
		case "DIAGNOSIS":
			UIUtils.clickElement(driver,
					TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "submenuDiag"));
			break;
		case "DRG":
			UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceDRG", "submenuDiag"));
			break;
		case "ICD":
			UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceICD", "submenuDiag"));
			break;
		case "PROCEDURE":
			UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("CodeMaintenancePC", "submenuDiag"));
			break;
		case "REVENUE":
			UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceRC", "submenuDiag"));
			break;
		case "DRUG":
			UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceDG", "submenuDiag"));
			break;
		default:
			System.out.println("Sbmenu not found");

			break;
		}

	}


	 */

	public boolean searchDiagnosiss() throws Exception {

		// UIUtils.selectValue(driver,
		// TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD",
		// "selectICD"),
		// "text", icd);
		Thread.sleep(1000);

		System.out.println("driver value =" + driver);

		// menu

		boolean isExist1 = UIUtils.isObjectExist(driver,
				TestConfig.getInstance().getObjRep().getLocator("Common", "menuBar"));
		System.out.println("The menu is present  ie traceable  =" + isExist1);
		boolean isExist = UIUtils.isObjectExist(driver,
				TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "buttonSearch"));
		System.out.println("The search button is traceable  =" + isExist);

		UIUtils.inputText(driver, TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "txtDiagCode"),
				"Zx21");
		// if element not found it will throw element not found exception
		//WebElement ele = driver.findElement(By.xpath("//input[@id='standard-description']"));
		//ele.sendKeys("Rahul's");
		// if element not found it will throw null pointer exception 
		// UIUtils.inputText(driver,TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "txtDiagDescription"),
		//"Zx21");

		UIUtils.inputText(driver,TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "txtDiagDescription"),
				"Zx21");
		UIUtils.clickElement(driver,
				TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "buttonSearch"));
		Thread.sleep(5000);

		return true;
	}

	public boolean searchDiagnosiss(String diagCode,String desc) throws Exception {

		// UIUtils.selectValue(driver,
		// TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD",
		// "selectICD"),
		// "text", icd);
		Thread.sleep(1000);

		System.out.println("diagCode value is "+diagCode);
		System.out.println("description value is "+desc);

		Thread.sleep(2000);

		System.out.println("driver value =" + driver);

		// menu

		boolean isExist1 = UIUtils.isObjectExist(driver,
				TestConfig.getInstance().getObjRep().getLocator("Common", "menuBar"));
		System.out.println("The menu is present  ie traceable  =" + isExist1);
		boolean isExist = UIUtils.isObjectExist(driver,
				TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "buttonSearch"));
		System.out.println("The search button is traceable  =" + isExist);

		UIUtils.inputText(driver, TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "txtDiagCode"),
				diagCode);
		// if element not found it will throw element not found exception
		//WebElement ele = driver.findElement(By.xpath("//input[@id='standard-description']"));
		//ele.sendKeys("Rahul's");
		// if element not found it will throw null pointer exception 
		// UIUtils.inputText(driver,TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "txtDiagDescription"),
		//"Zx21");

		UIUtils.inputText(driver,TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "txtDiagDescription"),
				desc);
		UIUtils.clickElement(driver,
				TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "buttonSearch"));
		Thread.sleep(5000);

		return true;
	}

	public boolean searchDiagnosissD( ) throws Exception { // get data from excel 



		Thread.sleep(2000);

		System.out.println("driver value =" + driver);



		//WebElement element = driver.findElement(TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "txtDiagCode")) ;
		//element.clear();
		//buttonReset
		UIUtils.clickElement(driver,
				TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "buttonReset"));
		UIUtils.inputText(driver, TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "txtDiagCode"),
				TestData.getData("searchDiag").get("DiagCode").toString());
		// if element not found it will throw element not found exception
		//WebElement ele = driver.findElement(By.xpath("//input[@id='standard-description']"));
		//ele.sendKeys("Rahul's");
		// if element not found it will throw null pointer exception 
		// UIUtils.inputText(driver,TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "txtDiagDescription"),
		//"Zx21");

		// element = driver.findElement(TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "txtDiagDescription")) ;
			//element.clear();
		UIUtils.inputText(driver,TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "txtDiagDescription"),
				TestData.getData("searchDiag").get("Description").toString());
		UIUtils.clickElement(driver,
				TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "buttonSearch"));
		Thread.sleep(5000);

		boolean isExist = UIUtils.isObjectExist(driver,TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "txtEditDiag"));  //txtEditDiag


		return isExist;
	}
	
	public boolean addDiagnosis( ) throws Exception { // get data from excel 
 
		Thread.sleep(2000); 

		UIUtils.clickElement(driver,
				TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "buttonAdd"));
		
		//UIUtils.inputText(driver, TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "txtDiagCode"),
				//TestData.getData("searchDiag").get("DiagCode").toString());
	 
		 
		Thread.sleep(2000);

		//boolean isExist = UIUtils.isObjectExist(driver,TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "txtEditDiag"));  //txtEditDiag


		return true;
	}
	

	public void closePopup() throws Exception {
		//buttonCancel

		UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "buttonCancel"));
		Thread.sleep(4000);

		Thread.sleep(3000);
		UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "buttonContinue"));
		Thread.sleep(3000);

		//driver.switchTo().defaultContent();
	}

}
