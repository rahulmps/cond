package com.birlasoft.automation.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.birlasoft.automation.driver.TestConfig;
import com.birlasoft.utils.UIUtils;

public class HomePage extends AbstractPage {
	static Logger LOGGER = Logger.getLogger(HomePage.class);
	WebDriverWait wWait;

	public HomePage(WebDriver driver) {
		super(driver);
		wWait = new WebDriverWait(driver, Integer.parseInt(TestConfig.getConfig().getPropertyValue("AVGWAITTIME")));
	 
	}

	@Override
	public boolean isPageOpen() {
		 
		boolean isExist = UIUtils.isObjectExist(driver,
				TestConfig.getInstance().getObjRep().getLocator("Common", "menuBar")); 
		return isExist;
	}

	public LoginPage logout() throws Exception {
	 

		UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("Common", "menuLogout1"));
		UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("Common", "menuLogout2")); 
		return PageFactory.initElements(driver, LoginPage.class);
	}

	public void closePopup() throws Exception {
		driver.switchTo().frame("did_dmode_frame_1");
		driver.switchTo().frame("mainframe");

		UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("Common", "btnOK"));

		driver.switchTo().defaultContent();
	}
	
	public CodeMaintanence clickCodeMaintanence() throws Exception{
		UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("Common", "menuCodeMaintenance"));
		
		
		return PageFactory.initElements(driver, CodeMaintanence.class);
		 
	}
	
	
	public CodeMaintanenceDiag clickCodeMaintanenceDiag() throws Exception{
		
		if( UIUtils.isObjectExist(driver,TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "submenuDiag"))){
			
		}else {
			UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("Common", "menuCodeMaintenance"));
			UIUtils.clickElement(driver,TestConfig.getInstance().getObjRep().getLocator("CodeMaintenanceD", "submenuDiag"));
			
			
			
		};
		
	
		return PageFactory.initElements(driver, CodeMaintanenceDiag.class);
		 
	}

	public AssigneePage clickAssignee() throws Exception {
		WebElement mainFrame = wWait.until(ExpectedConditions
				.presenceOfElementLocated(TestConfig.getInstance().getObjRep().getLocator("Common", "frameMain")));
		driver.switchTo().frame(mainFrame);

		WebElement displayFrame = wWait.until(ExpectedConditions
				.presenceOfElementLocated(TestConfig.getInstance().getObjRep().getLocator("Common", "frameDisplay")));
		driver.switchTo().frame(displayFrame);

		UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("Common", "menuAssignee"));
		driver.switchTo().defaultContent();
		return PageFactory.initElements(driver, AssigneePage.class);
	}

	public ClientsPage clickClients() throws Exception {
		// TODO
		WebElement mainFrame = wWait.until(ExpectedConditions
				.presenceOfElementLocated(TestConfig.getInstance().getObjRep().getLocator("Common", "frameMain")));
		driver.switchTo().frame(mainFrame);

		WebElement displayFrame = wWait.until(ExpectedConditions
				.presenceOfElementLocated(TestConfig.getInstance().getObjRep().getLocator("Common", "frameDisplay")));
		driver.switchTo().frame(displayFrame);
		
		UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("Common", "menuClients"));
		driver.switchTo().defaultContent();
		
		return PageFactory.initElements(driver, ClientsPage.class);
	}

	 
	 

	 

	public AdminPage clickAdmin() {
		// TODO
		return PageFactory.initElements(driver, AdminPage.class);
	}

	public BASFPage clickBASF() {
		// TODO
		return PageFactory.initElements(driver, BASFPage.class);
	}

	 

	@Override
	public boolean isPageOpen(String subMenu) {
		// TODO Auto-generated method stub
		return false;
	}
}