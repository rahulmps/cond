package com.birlasoft.automation.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.birlasoft.automation.driver.TestConfig;
import com.birlasoft.utils.UIUtils;

public class BASFPage extends AbstractPage {
	static Logger LOGGER = Logger.getLogger(BASFPage.class);
	WebDriverWait wWait;

	public BASFPage(WebDriver driver) {
		super(driver);
	}

	public void closePopup() throws Exception {
		WebElement popMainFrame = wWait.until(ExpectedConditions
				.presenceOfElementLocated(TestConfig.getInstance().getObjRep().getLocator("Common", "framePopup")));
		driver.switchTo().frame(popMainFrame);

		WebElement topFrame = wWait.until(ExpectedConditions
				.presenceOfElementLocated(TestConfig.getInstance().getObjRep().getLocator("Common", "framePopMain")));
		driver.switchTo().frame(topFrame);

		UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("Common", "btnOK"));

		driver.switchTo().defaultContent();
	}

	@Override
	public boolean isPageOpen() {
		WebElement mainFrame = wWait.until(ExpectedConditions
				.presenceOfElementLocated(TestConfig.getInstance().getObjRep().getLocator("Common", "frameMain")));
		driver.switchTo().frame(mainFrame);

		WebElement workFrame = wWait.until(ExpectedConditions
				.presenceOfElementLocated(TestConfig.getInstance().getObjRep().getLocator("Common", "frameWork")));
		driver.switchTo().frame(workFrame);

		WebElement workTopFrame = wWait.until(ExpectedConditions
				.presenceOfElementLocated(TestConfig.getInstance().getObjRep().getLocator("Common", "frameWorkTop")));
		driver.switchTo().frame(workTopFrame);

		// TODO - ADD logic
		boolean isExist = false;

		driver.switchTo().defaultContent();
		return isExist;
	}

	@Override
	public boolean isPageOpen(String subMenu) {
		// TODO Auto-generated method stub
		return false;
	}
}