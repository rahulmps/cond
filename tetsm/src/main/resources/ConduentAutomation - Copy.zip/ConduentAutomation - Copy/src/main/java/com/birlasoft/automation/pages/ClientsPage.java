package com.birlasoft.automation.pages;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.birlasoft.automation.driver.TestConfig;
import com.birlasoft.utils.UIUtils;

public class ClientsPage extends AbstractPage {
	static Logger LOGGER = Logger.getLogger(ClientsPage.class);
	WebDriverWait wWait;

	public ClientsPage(WebDriver driver) {
		super(driver);
	}


	@Override
	public boolean isPageOpen() {
		driver.switchTo().frame("did_appframe");
		driver.switchTo().frame("work");
		driver.switchTo().frame("work_top");		

		boolean isExist = UIUtils.isObjectExist(driver,
				TestConfig.getInstance().getObjRep().getLocator("Client", "txtClient"));
		driver.switchTo().defaultContent();
		return isExist;
	}

	public void searchClient(String client, String clientNumber, String country, String status) throws Exception {
		driver.switchTo().frame("did_appframe");
		driver.switchTo().frame("work");
		driver.switchTo().frame("work_top");

		if (StringUtils.isNotBlank(client)) {
			UIUtils.inputText(driver, TestConfig.getInstance().getObjRep().getLocator("Client", "txtClient" + 
					""), client);
		}

		if (StringUtils.isNotBlank(clientNumber)) {
			UIUtils.inputText(driver, TestConfig.getInstance().getObjRep().getLocator("Client", "ClientNumber"),
					clientNumber);
		}

		if (StringUtils.isNotBlank(country)) {
			UIUtils.selectValue(driver, TestConfig.getInstance().getObjRep().getLocator("Client", "ClientCountry"),
					country);
		}

		if (StringUtils.isNotBlank(status)) {
			UIUtils.selectValue(driver, TestConfig.getInstance().getObjRep().getLocator("Client", "ClientStatus"),
					status);
		}



		driver.switchTo().defaultContent();

		driver.switchTo().frame("did_appframe");
		driver.switchTo().frame("work");		
		driver.switchTo().frame("svc_select_btns");

		UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("Assignee", "btnSearch")); //ClientSearch 

		driver.switchTo().defaultContent();

		///////////////////////////////////

		



	}

	public boolean verifyClientSearch(String client, String clientNumber, String country, String status) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 3);
		Thread.sleep(20000);
		// driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"did_appframe\"]")));
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("did_appframe"));
		//wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("cp_display"));
		
		//driver.switchTo().frame("did_appframe");
		driver.switchTo().frame("work");
		driver.switchTo().frame("work_bottom");

		// TODO - Validation //txtGrid
		boolean result = false;

		String fileNumber1 = UIUtils.getText(driver.findElement(TestConfig.getInstance().getObjRep().getLocator("Client", "txtGrid")));

		System.out.println(" F NUM =  " +fileNumber1);

		result = clientNumber.equals(fileNumber1);

		driver.switchTo().defaultContent();

		return result;
	}


	@Override
	public boolean isPageOpen(String subMenu) {
		// TODO Auto-generated method stub
		return false;
	}


}