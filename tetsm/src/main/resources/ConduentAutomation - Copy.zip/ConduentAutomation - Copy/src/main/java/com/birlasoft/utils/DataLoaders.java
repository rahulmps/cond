package com.birlasoft.utils;

import java.io.IOException;
import java.util.List;

public class DataLoaders {
	public static Object[][] excelDataLoader(String excelPath) throws IOException {
		ExcelObject testDataObj = new ExcelObject(excelPath);
		return excelDataLoader(excelPath, testDataObj.getActiveSheet().getSheetName());
	}

	public static Object[][] excelDataLoader(String excelPath, String sheetName) throws IOException {
		ExcelObject testDataObj = new ExcelObject(excelPath);

		List<List<Object>> data = testDataObj.getExcelData(sheetName);

		testDataObj.closeWorkbook();

		Object[][] objects = new Object[data.size() - 1][];

		int i = 0;

		for (int ctr = 1; ctr < data.size(); ctr++) {
			List<Object> dataList = data.get(ctr);
			objects[i++] = dataList.toArray(new Object[dataList.size()]);
		}

		return objects;
	}
}