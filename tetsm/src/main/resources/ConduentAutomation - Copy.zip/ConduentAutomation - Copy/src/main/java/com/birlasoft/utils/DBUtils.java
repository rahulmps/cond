package com.birlasoft.utils;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

public class DBUtils {
	private static Logger LOGGER = Logger.getLogger(DBUtils.class);

	private static DBUtils dbUtils = new DBUtils();

	private DBUtils() {
	}

	public static DBUtils getInstance() {
		return dbUtils;
	}

	public Connection establishConnection(String driver, String connString)
			throws SQLException, ClassNotFoundException {
		LOGGER.info("Registering driver " + driver);

		Class.forName(driver);

		LOGGER.info("Setting up the connection with connection String " + connString);
		return DriverManager.getConnection(connString);
	}

	public Connection establishConnection(String driver, String connString, String userName, String password)
			throws SQLException, ClassNotFoundException {
		LOGGER.info("Registering driver " + driver);

		Class.forName(driver);

		LOGGER.info("Setting up the connection with connection String " + connString + " and user name " + userName);
		return DriverManager.getConnection(connString, userName, password);
	}

	public Connection establishConnection(String driver, String connString, Properties prop)
			throws SQLException, ClassNotFoundException {
		LOGGER.info("Registering driver " + driver);

		Class.forName(driver);

		LOGGER.info("Setting up the connection with connection String " + connString + " and properties");
		return DriverManager.getConnection(connString, prop);
	}

	public void closeConnection(Connection dbConn) throws SQLException {
		LOGGER.info("Closing the connection");
		dbConn.close();
	}

	// Execute Query - if varargs not present then Normal statement otherwise
	// Prepared Statement
	public List<List<Object>> executeQuery(Connection dbConn, String query, boolean includeColumnName,
			String... arguments) throws ClassNotFoundException, SQLException {
		List<List<Object>> queryResult = new ArrayList<>();

		LOGGER.info("Executing SQL query " + query);

		ResultSet result = null;
		List<Object> values;
		String colPrefix = "";

		try {
			if (arguments.length == 0) {
				Statement statement = dbConn.createStatement();
				result = statement.executeQuery(query);
				statement.close();
			} else {
				PreparedStatement pStatement = dbConn.prepareStatement(query);

				for (int ctr = 0; ctr < arguments.length; ctr++) {
					pStatement.setString(ctr + 1, arguments[ctr]);
				}

				result = pStatement.executeQuery();
				pStatement.close();
			}

			while (result.next()) {
				values = new ArrayList<Object>();
				int columnsCount = result.getMetaData().getColumnCount();

				for (int i = 1; i <= columnsCount; i++) {
					colPrefix = "";

					if (includeColumnName) {
						colPrefix = result.getMetaData().getColumnName(i) + Constants.COLUMN_SEPARATOR;
					}

					if (result.getObject(i) == null) {
						values.add(colPrefix + "");
					} else {
						values.add(colPrefix + result.getObject(i));
					}
				}
				queryResult.add(values);
			}
		} finally {
			result.close();
		}

		return queryResult;
	}

	// Update Query - if varargs not present then Normal statement otherwise
	// Prepared Statement
	public boolean updateQuery(Connection dbConn, String query, String... arguments)
			throws ClassNotFoundException, SQLException {
		int result;

		LOGGER.info("Executing DML query " + query);

		if (arguments.length == 0) {
			Statement statement = dbConn.createStatement();
			result = statement.executeUpdate(query);
			statement.close();
		} else {
			PreparedStatement pStatement = dbConn.prepareStatement(query);

			for (int ctr = 0; ctr < arguments.length; ctr++) {
				pStatement.setString(ctr + 1, arguments[ctr]);
			}
			result = pStatement.executeUpdate();
			pStatement.close();
		}

		if (result == 0) {
			LOGGER.info("No output returned for DML query " + query);
		} else if (result > 0) {
			LOGGER.info("Number of rows in the output returned for DML query is " + result);
		}

		return (result >= 0);
	}

	// Execute Proc - Callable Statement
	public List<List<Object>> executeProc(Connection dbConn, String query, String... arguments)
			throws ClassNotFoundException, SQLException {
		List<List<Object>> queryResult = new ArrayList<>();

		CallableStatement statement = null;
		ResultSet result = null;
		boolean blnResult = false;
		List<Object> values;
		LOGGER.info("Running proc " + query);

		try {
			statement = dbConn.prepareCall(query);

			if (arguments.length > 0) {
				for (int ctr = 0; ctr < arguments.length; ctr++) {
					statement.setString(ctr + 1, arguments[ctr]);
				}
			}

			blnResult = statement.execute();

			if (blnResult) {
				result = statement.getResultSet();

				while (result.next()) {
					values = new ArrayList<Object>();
					int columnsCount = result.getMetaData().getColumnCount();

					for (int i = 1; i <= columnsCount; i++) {
						if (result.getObject(i) == null) {
							values.add("");
						} else {
							values.add(result.getObject(i));
						}
					}
					queryResult.add(values);
				}
			}
		} finally {
			result.close();
			statement.close();
		}
		return queryResult;
	}
}