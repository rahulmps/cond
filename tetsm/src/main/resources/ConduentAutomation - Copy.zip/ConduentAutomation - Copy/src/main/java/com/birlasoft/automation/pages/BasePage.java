package com.birlasoft.automation.pages;

import java.io.IOException;

public interface BasePage {
	public boolean isPageOpen() throws IOException;
	
	public boolean isPageOpen(String subMenu) throws IOException;

	public boolean isElementExists(String screenName, String elementKey);

	public boolean isElementEnabled(String screenName, String elementKey);
}