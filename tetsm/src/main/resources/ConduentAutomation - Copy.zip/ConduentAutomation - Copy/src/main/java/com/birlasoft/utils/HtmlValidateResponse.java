package com.birlasoft.utils;

public class HtmlValidateResponse {

	private boolean pass;
	private String message;

	public boolean getPass() {
		return pass;
	}

	public void setPass(boolean pass) {
		this.pass = pass;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
