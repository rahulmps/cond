package com.birlasoft.utils;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Node;
import org.jsoup.select.NodeVisitor;
import org.openqa.selenium.WebDriver;

import com.birlasoft.automation.driver.TestConfig;
import com.birlasoft.automation.pages.AbstractPage;

public class HTMLTagValidator extends AbstractPage {

	private static String message = "";
	public HTMLTagValidator(WebDriver driver) {
		super(driver);
		message = "";
	}

	public HtmlValidateResponse validateHtmlTags() {
		HtmlValidateResponse htmlValidateResponse = new HtmlValidateResponse();
		Document document = Jsoup.parse(driver.getPageSource());
        document.traverse(new NodeVisitor() {
            public void head(Node node, int depth){
            	message += "Node start: " + node.nodeName();
            }
            public void tail(Node node, int depth){
            	message += "Node end: " + node.nodeName();
            }
        });
        htmlValidateResponse.setPass(true);
        htmlValidateResponse.setMessage(message);
		return htmlValidateResponse;
	}

	@Override
	public boolean isPageOpen() {
		if (UIUtils.isObjectExist(driver, TestConfig.getInstance().getObjRep().getLocator("Common", "OKGOTIT"))) {
			try {
				UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("Common", "OKGOTIT"));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return UIUtils.isObjectExist(driver, TestConfig.getInstance().getObjRep().getLocator("Common", "MajorIndexes"));
	}

	@Override
	public boolean isPageOpen(String subMenu) {
		// TODO Auto-generated method stub
		return false;
	}
}