package com.birlasoft.automation.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.birlasoft.automation.driver.TestConfig;
import com.birlasoft.utils.UIUtils;

public class LoginPage extends AbstractPage {
	static Logger LOGGER = Logger.getLogger(LoginPage.class);
	
	public LoginPage(WebDriver driver) {
		super(driver);
	}

	@Override
	public boolean isPageOpen() {
		return UIUtils.isObjectExist(driver, TestConfig.getInstance().getObjRep().getLocator("Login", "txtUserId"))
				&& UIUtils.isObjectExist(driver, TestConfig.getInstance().getObjRep().getLocator("Login", "txtPassword"))
				&& UIUtils.isObjectExist(driver, TestConfig.getInstance().getObjRep().getLocator("Login", "btnLogin"));
	}
	
	public HomePage login(String userName, String password) throws Exception {
		UIUtils.inputText(driver, TestConfig.getInstance().getObjRep().getLocator("Login", "txtUserId"), userName);
		//UIUtils.inputText(driver, TestConfig.getInstance().getObjRep().getLocator("Login", "txtPassword"), password);
		UIUtils.clickElement(driver, TestConfig.getInstance().getObjRep().getLocator("Login", "btnLogin"));
		return PageFactory.initElements(driver, HomePage.class);
	}

	@Override
	public boolean isPageOpen(String subMenu) {
		// TODO Auto-generated method stub
		return false;
	}
}