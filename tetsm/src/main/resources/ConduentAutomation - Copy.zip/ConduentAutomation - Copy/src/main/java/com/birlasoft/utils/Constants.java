package com.birlasoft.utils;

import org.openqa.selenium.By;

public class Constants {
	public static final String CONDITION_SEPARATOR = ";";
	public static final String CONDITIONVALUE_SEPARATOR = "=";
	protected static final String COLUMN_SEPARATOR = "=";
	protected static final By BYSPINNER = By.id("did_meterProgressBar");
}