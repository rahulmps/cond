package com.birlasoft.automation.tests;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.birlasoft.automation.driver.TestConfig;
import com.birlasoft.automation.driver.TestDriver;
import com.birlasoft.automation.pages.AssigneePage;
import com.birlasoft.automation.pages.HomePage;
import com.birlasoft.automation.pages.LoginPage;
import com.birlasoft.framework.ExtentManager;
import com.birlasoft.framework.LogMe;
import com.birlasoft.utils.UIUtils;
import com.relevantcodes.extentreports.LogStatus;
import com.sun.istack.logging.Logger;

public class TestsCommon {
	static LogMe LOGGER;
	private WebDriver driver;

	@BeforeSuite
	public void suiteSetup() {
		try {
			LOGGER = new LogMe(TestsCommon.class);
			TestConfig.getInstance().suiteSetup();

			driver = TestDriver.driverInstantiation(TestConfig.getInstance().getBrowserName().toUpperCase());

			LogMe.getLogger().info("Base URL is " + TestConfig.getInstance().getAppBaseURL());

			driver.get(TestConfig.getInstance().getAppBaseURL());

			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			driver.manage().timeouts().setScriptTimeout(30, TimeUnit.SECONDS);

			UIUtils.waitForPageLoad(driver);

			if (!TestConfig.getInstance().getDeviceResolution().equals("Full Screen")) {
				String[] dim = TestConfig.getInstance().getDeviceResolution().split(",");
				int dimX = Integer.parseInt(dim[0]);
				int dimY = Integer.parseInt(dim[1]);
				Dimension d = new Dimension(dimX, dimY);
				driver.manage().window().setSize(d);
			} else {
				driver.manage().window().maximize();
			}

			LOGGER.logInfo("*********EXECUTION STARTED**********\n\n");
		} catch (Exception e) {
			LOGGER.logError("Exception " + e.getClass().getName() + " caught from suite setup method", e);
		}
	}

	@BeforeMethod
	public void startReporting(Method method) throws Exception {
		LOGGER.logBeginTestCase(method.getName());
	}

	@Test(description = "TC-Login & Logout Functionality TC ", priority = 0, enabled = true)
	public void tc01LoginLogout() throws Exception {
		LoginPage login = PageFactory.initElements(driver, LoginPage.class);
		
		AssigneePage Assigne;

		// Validation whether login is displaying or not
		Assert.assertTrue(login.isPageOpen());
		LOGGER.logTestStep("PASS", "Login page is displaying");

		// Trying to login into the application
		HomePage home = login.login(TestConfig.getDataConfig().getPropertyValue("userName"),
				TestConfig.getDataConfig().getPropertyValue("secret"));

		// Validation whether login is successful or not
		Assert.assertTrue(home.isPageOpen());
		LOGGER.logTestStep("PASS", "Home page is displaying - Login successful");
		
		Assigne = home.clickAssignee();
		LOGGER.logInfo("Click assigne ");

		// Trying to logout from the application
		login = home.logout();

		// Validation whether login is displaying or not
		Assert.assertTrue(login.isPageOpen());
		LOGGER.logTestStep("PASS", "Login page is displaying - Logout is successful");
	}

	@AfterMethod
	public void testResult(Method method, ITestResult result) throws IOException {
		switch (result.getStatus()) {
		case ITestResult.SUCCESS:
			LogMe.getExtentTest().log(LogStatus.PASS, "Test Case " + method.getName() + " is pass");
			break;
		case ITestResult.FAILURE:
			LogMe.getExtentTest().log(LogStatus.FAIL, "Test Case " + method.getName() + " failed");
			break;
		case ITestResult.SKIP:
			LogMe.getExtentTest().log(LogStatus.SKIP, "Test Case " + method.getName() + "  skiped");
			break;
		default:
			break;
		}
		LOGGER.logEndTestCase(method.getName());
	}

	@AfterSuite
	public void generateResult() {
		try {
			ExtentManager.getInstance().flush();
		} finally {
			ExtentManager.getInstance().close();
		}
		driver.close();
	}
}